- If you want to use the computers at IFI, please open the jupyter notebook using (python3): "/opt/ifi/anaconda3/bin/jupyter-notebook"




