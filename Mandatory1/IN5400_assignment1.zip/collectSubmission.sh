rm -f IN5400_assignment1.zip 
zip -r IN5400_assignment1.zip . -x    "*.ipynb_checkpoints
*" ".env/*" "in5400_2019_mandatory1_assignment.zip"
